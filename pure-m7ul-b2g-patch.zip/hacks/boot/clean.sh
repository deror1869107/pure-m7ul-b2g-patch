rm -rf initramfs_dir initramfs.cpio.gz zImage newinitramfs.cpio.gz new_boot.img
