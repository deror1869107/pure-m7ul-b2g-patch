adb push modules /system/lib/modules/
adb push ../B2G/out/target/product/m7ul/data/local/ /data/local/
