mkdir -p out/target/product/m7ul/obj/KERNEL_OBJ/usr

cp kernel/htc/m7/include/linux/msm_* external/kernel-headers/original/linux/
cp hardware/qcom/msm8960/original-kernel-headers/linux/msm_ion.h external/kernel-headers/original/linux/
cd bionic/libc/kernel/tools
./update_all.py
cd ../../../../
cp kernel/htc/m7/include/video/msm_hdmi_modes.h bionic/libc/kernel/common/video/
cp kernel/htc/m7/include/sound/compress_offload.h bionic/libc/kernel/common/sound/

cp hacks/kernel out/target/product/m7ul/

cd bootable/recovery
mkdir fonts
cd fonts
wget https://raw.github.com/Mahdi-Rom/android_bootable_recovery/jb-4.3/fonts/12x22.png
wget https://raw.github.com/Mahdi-Rom/android_bootable_recovery/jb-4.3/fonts/18x32.png

